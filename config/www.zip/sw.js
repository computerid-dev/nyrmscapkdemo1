// Service worker NYR Musik: simpan seluruh cangkang aplikasi (termasuk layar loading) supaya
// bisa dibuka penuh tanpa internet. API dan situs luar tidak disentuh.
const CACHE = "nyr-msc-strm-shell-v3";
const SHELL = [
  "./", "./index.html", "./loading.js", "./manifest.webmanifest",
  "./nyr-msc-strm/index.html", "./nyr-msc-strm/style.css", "./nyr-msc-strm/config.js", "./nyr-msc-strm/zip.js",
  "./nyr-msc-strm/data.js", "./nyr-msc-strm/net.js", "./nyr-msc-strm/app.js",
  "./nyr-msc-strm/icons/icon-192.png", "./nyr-msc-strm/icons/icon-512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    fetch(req)
      .then((res) => {
        if (res.ok) {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy));
        }
        return res;
      })
      .catch(() =>
        caches.match(req, { ignoreSearch: true }).then((hit) => hit || (req.mode === "navigate" ? caches.match("./index.html") : Response.error()))
      )
  );
});
